# Version 1.0.0 — Foundation rebuild
- New Android WebView project and clean local web interface.
- Practice sessions, answer explanations, bookmarks, wrong-answer review, cases, and local question import.
- Preserved an initial bank from the previous app, removing exact repeated question texts.
- Added stable IDs to local review and bookmark workflows.
