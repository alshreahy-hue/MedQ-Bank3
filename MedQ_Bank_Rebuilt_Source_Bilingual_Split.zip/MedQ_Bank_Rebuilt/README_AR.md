# MedQ Bank — مشروع جديد من الأساس

هذا مشروع أندرويد جديد بواجهة HTML/CSS/JavaScript داخل Android WebView، مع بيانات الأسئلة والحالات مضمّنة محلياً للعمل دون اتصال.

## الموجود في النسخة الأولية
- لوحة رئيسية وإحصائيات محلية.
- تدريب بأسئلة اختيار من متعدد، مع تفسير الإجابة.
- حفظ المفضلة والإجابات الخاطئة باستخدام معرّفات الأسئلة.
- عرض الحالات السريرية.
- استيراد أسئلة إضافية بصيغة JSON من داخل التطبيق.
- حفظ التقدم محلياً على الجهاز.

## البيانات الأولية
أُخذت الأسئلة والحالات المتوفرة من ملف التطبيق السابق، وأزيلت سجلات الأسئلة المتطابقة نصياً فقط. هذه ليست مراجعة علمية كاملة؛ يجب التحقق من الإجابات الطبية قبل الاستخدام التعليمي الجاد.

## بناء APK
المشروع يحتاج إلى Android Studio حديث وJDK 17 أو أحدث، مع Android SDK Platform 35.
1. فك ضغط المشروع.
2. افتح مجلد `MedQ_Bank_Rebuilt` من Android Studio.
3. وافق على مزامنة Gradle وتنزيل الأدوات المطلوبة.
4. اختر Build > Build APK(s).
5. سيظهر APK عادة في `app/build/outputs/apk/debug/app-debug.apk`.

لا يحتوي هذا الأرشيف على APK مبني ومختبَر؛ بيئة العمل الحالية لا تحتوي على Android SDK/Gradle لبناء حزمة أندرويد محلياً. افتح المشروع في Android Studio لبنائه.

## إضافة الأسئلة لاحقاً
من داخل التطبيق افتح **Add questions** والصق مصفوفة JSON. مثال:

```json
[
  {
    "id": "CARD-0001",
    "subject": "Cardiology",
    "difficulty": "Easy",
    "question": "Which chamber pumps blood into the aorta?",
    "options": ["Right atrium", "Right ventricle", "Left atrium", "Left ventricle"],
    "answer": 3,
    "explanation": "The left ventricle pumps oxygenated blood into the aorta."
  }
]
```

مؤشر `answer` يبدأ من صفر: الخيار الأول = 0، والثاني = 1، وهكذا.
